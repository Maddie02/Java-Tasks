package test.food;

import tues.McBurger;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class McBurgerTest {
    @Test
    void passWinter() {
        McBurger burger = new McBurger(20, 10);
        assertEquals(burger.getFoodScore(), 200);

        burger.passWinter();
        assertEquals(burger.getFoodScore(), 80);
        assertEquals(burger.getAge(), 1);

        burger.passWinter();
        assertEquals(burger.getFoodScore(), 80);
        assertEquals(burger.getAge(), 2);
    }
}
