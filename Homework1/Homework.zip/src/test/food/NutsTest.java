package test.food;

import tues.Nuts;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NutsTest {
    @Test
    void passWinter() {
         Nuts nuts = new Nuts(20, 10);
         assertEquals(nuts.getFoodScore(), 200);

         nuts.passWinter();
         assertEquals(nuts.getFoodScore(), 200);
         assertEquals(nuts.getAge(), 1);

         nuts.passWinter();
         assertEquals(nuts.getFoodScore(), 200);
         assertEquals(nuts.getAge(), 2);
    }
}
