package task;

public enum EngineType {
    DIESEL, GASOLINE, ELECTRIC, HYBRID
}
