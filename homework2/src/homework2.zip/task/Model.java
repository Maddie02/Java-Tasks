package task;

public enum Model {
    ALFA_ROMEO, AUDI, BMW, MERCEDES, FERRARI, OPEL
}
